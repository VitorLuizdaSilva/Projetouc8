package br.com.senai.projetouc8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projetouc8Application {

	public static void main(String[] args) {
		SpringApplication.run(Projetouc8Application.class, args);
	}

}
