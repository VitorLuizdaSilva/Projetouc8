package br.com.senai.exspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
